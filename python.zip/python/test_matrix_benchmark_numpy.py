import numpy as np

# Dimensión de las matrices
n = 1024

# Inicialización de las matrices con NumPy
def initialize_matrices():
    a = np.random.rand(n, n)
    b = np.random.rand(n, n)
    return a, b

# Función que realiza la multiplicación de matrices usando NumPy
def matrix_multiplication(a, b):
    c = np.dot(a, b)
    return c

# Test con benchmark usando pytest-benchmark
def test_matrix_multiplication_numpy(benchmark):
    # Inicializar las matrices
    a, b = initialize_matrices()

    # Ejecutar el benchmark
    result = benchmark.pedantic(matrix_multiplication, args=(a, b), iterations=1, rounds=10)

    # (Opcional) Validar el tamaño de la matriz resultante
    assert result.shape == (n, n)
