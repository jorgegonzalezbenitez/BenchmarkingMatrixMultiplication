def my_function(numbers):
 return sum(x**2 for x in numbers)
def test_my_function(benchmark):
 numbers = [1, 2, 3, 4, 5]
 result = benchmark.pedantic(my_function, args=(numbers,),
 iterations=100, rounds=10)
 assert result == 55
 
 