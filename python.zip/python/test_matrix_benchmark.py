import random

# Dimensión de las matrices
n = 10

# Inicialización de las matrices
def initialize_matrices():
    a = [[random.random() for _ in range(n)] for _ in range(n)]
    b = [[random.random() for _ in range(n)] for _ in range(n)]
    c = [[0 for _ in range(n)] for _ in range(n)]
    return a, b, c

# Función que realiza la multiplicación de matrices
def matrix_multiplication(a, b, c):
    for i in range(n):
        for j in range(n):
            for k in range(n):
                c[i][j] += a[i][k] * b[k][j]
    return c
    execution_time = timeit.timeit(matrix_multiplication, number=1)

# Test con benchmark usando pytest-benchmark
def test_matrix_multiplication(benchmark):
    # Inicializar las matrices
    a, b, c = initialize_matrices()

    # Ejecutar el benchmark
    result = benchmark.pedantic(matrix_multiplication, args=(a, b, c), iterations=1, rounds=10)
   

    # (Opcional) Validar la estructura de la matriz resultante
    assert len(result) == n and len(result[0]) == n
    
